# Code from my Medium articles
Make sure to have Jupyter Notebook installed, sit back and shift enter ;)
